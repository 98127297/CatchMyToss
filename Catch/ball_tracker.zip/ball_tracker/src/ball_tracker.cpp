#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>

static const std::string IMAGE_WINDOW = "Image window";
static const std::string DEPTH_WINDOW = "Depth window";

//HSV STRUCT
//struct HSV{
//    int iLowH;
//    int iHighH;
//    int iLowS;
//    int iHighS;
//    int iLowV;
//    int iHighV;
//} golf, pingpong;
//golf.iLowH = 0;
//golf.iHighH = 19;
//golf.iLowS = 98;
//golf.iHighS = 255;
//golf.iLowV = 163;
//golf.iHighV = 255;

class ImageConverter
{
  ros::NodeHandle nh_;
  image_transport::ImageTransport it_;
  image_transport::Subscriber image_sub_;
  image_transport::Publisher image_pub_;
  image_transport::Subscriber depth_sub_;
  image_transport::Publisher depth_pub_;

public:
  ImageConverter()
    : it_(nh_)
  {
    // Subscrive to input video feed and publish output video feed
    image_sub_ = it_.subscribe("/kinect2/hd/image_color_rect", 1,
      &ImageConverter::imageCb, this);

    depth_sub_ = it_.subscribe("/kinect2/hd/image_depth_rect", 1,
      &ImageConverter::depthCb, this);
    
    image_pub_ = it_.advertise("/image_converter/output_image", 1);

    depth_pub_ = it_.advertise("/depth_converter/output_depth",1);

    cv::namedWindow(IMAGE_WINDOW);
	cv::namedWindow(DEPTH_WINDOW);
  }

  ~ImageConverter()
  {
    cv::destroyWindow(IMAGE_WINDOW);
	cv::destroyWindow(DEPTH_WINDOW);
  }

  void imageCb(const sensor_msgs::ImageConstPtr& msg)
  {
    cv_bridge::CvImagePtr cv_ptr;
    try
    {
      cv_ptr = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::BGR8);
    }
    catch (cv_bridge::Exception& e)
    {
      ROS_ERROR("cv_bridge exception: %s", e.what());
      return;
    }

    // Draw an example circle on the video stream
    //if (cv_ptr->image.rows > 60 && cv_ptr->image.cols > 60)
     // cv::circle(cv_ptr->image, cv::Point(50, 50), 10, CV_RGB(255,0,0));
	//cv::putText(cv_ptr->image, 
	//	"Here is some text",
	//	cv::Point(cv_ptr->image.cols/2,cv_ptr->image.rows/2), // Coordinates
	//	cv::FONT_HERSHEY_COMPLEX_SMALL, // Font
	//	1.0, // Scale. 2.0 = 2x bigger
	//	cv::Scalar(255,0,0), // BGR Color
	//	1, // Line Thickness (Optional)
	//	CV_AA); // Anti-alias (Optional)
    // Update GUI Window
    cv::imshow(IMAGE_WINDOW, cv_ptr->image);
    cv::waitKey(3);

    // Output modified video stream
    image_pub_.publish(cv_ptr->toImageMsg());
  }
  
  void depthCb(const sensor_msgs::ImageConstPtr& msg)
  {
    cv_bridge::CvImagePtr cv_ptr;
    try
    {
      cv_ptr = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::TYPE_16UC1);
    }
    catch (cv_bridge::Exception& e)
    {
      ROS_ERROR("cv_bridge exception: %s", e.what());
      return;
    }

    // Draw an example circle on the video stream
   // if (cv_ptr->image.rows == image.rows/2 && cv_ptr->image.cols == image.cols/2)
   //   cv::circle(cv_ptr->image, cv::Point(50, 50), 10, CV_RGB(255,0,0));

	// Print pixel value of depth image at centre
	//std::cout << cv_ptr->image.at<uint16_t>(cv_ptr->image.rows/2,cv_ptr->image.cols/2) << std::endl;

	//Print pixel values at centre of screen	
	//std::cout << cv_ptr->image.cols/2 << std::endl;	//960 pixel
	//std::cout << cv_ptr->image.rows/2 << std::endl;	//540 pixel

    // Update GUI Window
    cv::imshow(DEPTH_WINDOW, cv_ptr->image);
    cv::waitKey(3);

    // Output modified video stream
    image_pub_.publish(cv_ptr->toImageMsg());
  }
};

int main(int argc, char** argv)
{
  ros::init(argc, argv, "image_converter");
  ImageConverter ic;
  ros::spin();
  return 0;
}
