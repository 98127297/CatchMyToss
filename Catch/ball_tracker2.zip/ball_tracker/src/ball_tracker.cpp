#include <stdio.h>
#include <sstream>
#include <string>
//#include <stlib.h>
#include <iostream>#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <geometry_msgs/PointStamped.h>
#include <opencv2/videoio.hpp>
#include <opencv2/video.hpp>
//#include "background_segm.hpp"

static const std::string IMAGE_WINDOW = "Image window";
static const std::string PROCESSED_WINDOW = "Processed";
static const std::string DEPTH_WINDOW = "Depth window";
static const uint16_t MAX_KINECT_RANGE = 10000;

////HSV STRUCT (Hue, Saturation, Value)
//struct Hsv{
//    int lowH;
//    int highH;
//    int lowS;
//    int highS;
//    int lowV;
//    int highV;
//};

//Hsv golfBall = {0, 19, 98, 255, 163, 255};

//cv::Mat previousFrame;
//cv::Mat absoluteDiff;

class ImageConverter
{
  ros::NodeHandle nh_;
  image_transport::ImageTransport it_;
  image_transport::Subscriber image_sub_;
  image_transport::Publisher image_pub_;
  image_transport::Subscriber depth_sub_;
  image_transport::Publisher depth_pub_;
  ros::Publisher depth_ball_pub_;

  //Thresholds for the HSV filtering
  cv::Scalar hsvMin;
  cv::Scalar hsvMax;
  //Depth map
  cv::Mat depthMap;
  //Circle image
  cv::Mat imageCircle;
  //HSV image
  cv::Mat imageHsv;
  //Filtered HSV image
  cv::Mat filteredHsv;
  //Structuring Element - dilation
  cv::Mat dilateElement;
  //Structuring Element - erosion
  cv::Mat erodeElement;
  //Gaussian kernel
  cv::Size gaussianKernel;
  //Circles found by Hough Circles Transform
  std::vector<cv::Vec3f> circles;

  //Background subtractor
  cv::Ptr<cv::BackgroundSubtractor> subtractor;
  //Mask
  cv::Mat mask;
  //Flag
//  bool flag;
  //Mat for previous Frame
//  cv::Mat previousFrame;
  //Mat for difference
//  cv::Mat absoluteDiff;


public:
  ImageConverter()
    : it_(nh_), hsvMin(cv::Scalar(12,74,222)), hsvMax(cv::Scalar(38,255,255)),
      dilateElement(cv::getStructuringElement(cv::MORPH_ELLIPSE,cv::Size(3,3))), erodeElement(cv::getStructuringElement(cv::MORPH_ELLIPSE,cv::Size(3,3))),
      gaussianKernel(cv::Size(9,9)), subtractor(cv::createBackgroundSubtractorMOG2())
  {
    //SUBSCRIBERS
    // Subscrive to input video feed and publish output video feed
    image_sub_ = it_.subscribe("/kinect2/hd/image_color_rect", 1,
      &ImageConverter::imageCb, this);

//    depth_sub_ = it_.subscribe("/kinect2/hd/image_depth_rect", 1,
//      &ImageConverter::depthCb, this);
    
    //PUBLISHERS
    image_pub_ = it_.advertise("/image_converter/output_image", 1);

//    depth_pub_ = it_.advertise("/depth_converter/output_depth",1);
    depth_ball_pub_ = nh_.advertise<geometry_msgs::PointStamped>("/ball_tracker", 1);


    cv::namedWindow(IMAGE_WINDOW);
    cv::namedWindow(PROCESSED_WINDOW);
    //cv::namedWindow(DEPTH_WINDOW);
  }

  ~ImageConverter()
  {
    cv::destroyWindow(IMAGE_WINDOW);
    //cv::destroyWindow(DEPTH_WINDOW);
    cv::destroyWindow(PROCESSED_WINDOW);
  }

  void imageCb(const sensor_msgs::ImageConstPtr& msg)
  {
    cv_bridge::CvImagePtr cv_ptr;
    try
    {
      cv_ptr = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::BGR8);
    }
    catch (cv_bridge::Exception& e)
    {
      ROS_ERROR("cv_bridge exception: %s", e.what());
      return;
    }

    // Draw an example circle on the video stream
    //if (cv_ptr->image.rows > 60 && cv_ptr->image.cols > 60)
     // cv::circle(cv_ptr->image, cv::Point(50, 50), 10, CV_RGB(255,0,0));
	//cv::putText(cv_ptr->image, 
	//	"Here is some text",
	//	cv::Point(cv_ptr->image.cols/2,cv_ptr->image.rows/2), // Coordinates
	//	cv::FONT_HERSHEY_COMPLEX_SMALL, // Font
	//	1.0, // Scale. 2.0 = 2x bigger
	//	cv::Scalar(255,0,0), // BGR Color
	//	1, // Line Thickness (Optional)
	//	CV_AA); // Anti-alias (Optional)

    imageCircle = cv_ptr->image;
    //Convert image to HSV
    cvtColor(cv_ptr->image, imageHsv, cv::COLOR_BGR2HSV);

    //Filtering to find orange golf ball
    cv::inRange(imageHsv, hsvMin, hsvMax, filteredHsv);

    //Subtractor for masking out static
    subtractor->apply(filteredHsv, mask);

    //erode and dilate
    cv::erode(mask,mask,erodeElement,cv::Point(-1,-1),6);
    cv::dilate(mask,mask,dilateElement,cv::Point(-1,-1),6);

    cv::GaussianBlur(mask,mask,gaussianKernel,9,9);
//    Hough Circle filter
    cv::HoughCircles(mask, circles, CV_HOUGH_GRADIENT, 1, mask.rows/2, 20, 10, 5, 100);

//    if (flag == 0){
//        previousFrame = filteredHsv;
////        std::cout << "Here" << std::endl;
//        flag = 1;
//    }
//    cv::absdiff(filteredHsv,previousFrame, absoluteDiff);

//    previousFrame = filteredHsv;
//    cv::erode(absoluteDiff,absoluteDiff,erodeElement,cv::Point(-1,-1),1);
//    cv::dilate(absoluteDiff,absoluteDiff,erodeElement,cv::Point(-1,-1),1);

    //Erode --> dilate = reduce white noise (morphological opening)
    //Erode to take away white noise
//    cv::erode(filteredHsv,filteredHsv,erodeElement,cv::Point(-1,-1),3); //1 at end is iterations, increase for more erosion
    //Dilate to enhance white golf ball
//    cv::dilate(filteredHsv,filteredHsv,dilateElement,cv::Point(-1,-1),5);
    //Fill out the golf ball
//    cv::dilate(filteredHsv,filteredHsv,cv::getStructuringElement(cv::MORPH_ELLIPSE,cv::Size(11,11)),cv::Point(-1,-1),5);

    //Dilate --> erode = increase white spots (morphological closing)
//    cv::dilate(filteredHsv,filteredHsv,dilateElement,cv::Point(-1,-1),7);
    //cv::erode(filteredHsv,filteredHsv,erodeElement,cv::Point(-1,-1),1); //1 at end is iterations, increase for more erosion

    //Smoothing image
//    cv::GaussianBlur(filteredHsv,filteredHsv,gaussianKernel,9,9);

//    int type = filteredHsv.type();
//    std::cout << type << std::endl;
//    Hough Circle filter
//    cv::HoughCircles(filteredHsv, circles, CV_HOUGH_GRADIENT, 1, filteredHsv.rows/8, 50, 25, 20, 100);

    //std::cout << circles.size() << std::endl;
    //Post circles to IMAGE_WINDOW
    for( size_t i = 0; i < circles.size(); i++ )
    {
        //std::cout << "circle: " << i << std::endl;
        cv::Point center(cvRound(circles[i][0]), cvRound(circles[i][1]));
        int radius = cvRound(circles[i][2]);
        // circle center
        cv::circle( imageCircle, center, 3, cv::Scalar(0,255,0), -1, 8, 0 );
        // circle outline
        cv::circle( imageCircle, center, radius, cv::Scalar(0,0,255), 3, 8, 0 );
        cv::putText( imageCircle, "Test", center, cv::FONT_HERSHEY_DUPLEX, 1, cv::Scalar(255,0,0),2);
    }
//    // Update GUI Window
    cv::imshow(IMAGE_WINDOW, imageCircle);
//    cv::imshow(IMAGE_WINDOW, cv_ptr->image);
//    cv::imshow(PROCESSED_WINDOW, absoluteDiff);
//    cv::imshow(IMAGE_WINDOW, filteredHsv);
    cv::imshow(PROCESSED_WINDOW, mask);
    cv::waitKey(3);

    // Output modified video stream
    image_pub_.publish(cv_ptr->toImageMsg());
  }
  
  void depthCb(const sensor_msgs::ImageConstPtr& msg)
  {
    cv_bridge::CvImagePtr cv_ptr;
    try
    {
      cv_ptr = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::TYPE_16UC1);
    }
    catch (cv_bridge::Exception& e)
    {
      ROS_ERROR("cv_bridge exception: %s", e.what());
      return;
    }

    // Draw an example circle on the video stream
   // if (cv_ptr->image.rows == image.rows/2 && cv_ptr->image.cols == image.cols/2)
   //   cv::circle(cv_ptr->image, cv::Point(50, 50), 10, CV_RGB(255,0,0));

	// Print pixel value of depth image at centre
	//std::cout << cv_ptr->image.at<uint16_t>(cv_ptr->image.rows/2,cv_ptr->image.cols/2) << std::endl;

	//Print pixel values at centre of screen	
	//std::cout << cv_ptr->image.cols/2 << std::endl;	//960 pixel
	//std::cout << cv_ptr->image.rows/2 << std::endl;	//540 pixel

    depthMap = cv_ptr->image;   //Depth map represents each pixel as it's distance in millimeters
    //Brighten depth map by bumping up pixel values using percentage from max value, max value kinect2 can read accurately = 5 metres
//    for(int i = 1; depthMap.cols < i; i++)
//    {
//        for(int j = 1; depthMap.rows < j; j++)
//        {
//            if(depthMap.at<uint16_t>(i,j) > MAX_KINECT_RANGE){
//                depthMap.at<uint16_t>(i,j) = MAX_KINECT_RANGE;
//            }
//            depthMap.at<uint16_t>(i,j) = cvRound((depthMap.at<uint16_t>(i,j) / MAX_KINECT_RANGE)*65536);
//        }
//    }

    // Update GUI Window
    cv::imshow(DEPTH_WINDOW, depthMap);
    cv::waitKey(3);

    // Output modified video stream
    depth_pub_.publish(cv_ptr->toImageMsg());
  }
};

int main(int argc, char** argv)
{
  ros::init(argc, argv, "image_converter");
  ImageConverter ic;
  ros::spin();
  return 0;
}
